

<?php if(session("success")): ?>
        <div class="alert alert-success">
                <?php echo e(session("success")); ?>

        </div>
<?php endif; ?>

<?php if(session("error")): ?>
        <div class="alert alert-danger">
                <?php echo e(session("error")); ?>

        </div>
<?php endif; ?>

<?php /**PATH /home/arjun/website/flood/resources/views/inc/messages.blade.php ENDPATH**/ ?>