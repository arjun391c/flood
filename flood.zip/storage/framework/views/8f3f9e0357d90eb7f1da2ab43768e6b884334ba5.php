<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<style>
body{
  /* overflow-y: hidden; */
}
</style>
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto  flex-column lets">

        <main role="main" class="jumbotron inner cover text-center" id="hmj">
          <h1 class="cover-heading text-center"  id="uptxt">Let's Find</h1><hr style="background-color:white">

          <p class="lead text-center" id="cap">
              Sometimes Things That Are Lost<br>
              Can be Found Again
              <hr style="background-color:aliceblue;  width:150px;">
          </p>
          <br>

          <p class="lead">
            <a href="/posts/upload" class="btn btn-lg  btn-primary  ">Upload</a>
            <a href="/posts" class="btn  btn-lg btn-success ml-3  " style="width:6.3rem" >Find</a>
          </p>

        </main>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arjun/website/flood/resources/views/welcome.blade.php ENDPATH**/ ?>