<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="py-5 text-center">

          <h2>Details</h2>
          
        </div>

        <div class="row">

                <div class="jumbotron col-md-5  mb-6 mr-md-5">
                        <h4 class="d-flex justify-content-between align-items-center mb-3">
                          <span class="text-muted">Whom to Contact</span>
                        </h4>
                        <hr>
                        <ul class="list-group mb-3">

                          <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                              <h6 class="my-0">Name</h6>
                            </div>
                            <span class="text-muted"><?php echo e($post->name); ?></span>
                          </li>

                          <li class="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                  <strong><h6 class="my-0">Phone</h6></strong>

                                </div>
                                <span class="text-muted"><?php echo e($post->phone); ?></span>
                          </li>

                          <?php if($post->email): ?>
                          <li class="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                  <strong><h6 class="my-0">Email</h6></strong>

                                </div>
                                <?php if($post->email != NULL): ?>
                                    <span class="text-muted"><?php echo e($post->email); ?></span>
                                <?php else: ?>
                                    <small class="text-muted">No email specified</small>
                                <?php endif; ?>
                           </li>
                           <?php endif; ?>


                        </ul>

                      </div>


                    <div class="jumbotron col-md-5  mb-6 ml-md-5">
                            <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Search Results</span>
                      </h4>
                      <hr>
                      <ul class="list-group mb-3">
                      <?php if($post->dfname): ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                          <div>
                            <h6 class="my-0">Name as on document</h6>

                          </div>
                          <span class="text-muted"><?php echo e($post->dfname); ?>. <?php echo e($post->dlname); ?></span>
                        </li>
                        <?php endif; ?>
                        <?php if($post->doc): ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                              <div>
                                <strong><h6 class="my-0">Document Type</h6></strong>

                              </div>
                              <span class="text-muted"><?php echo e($post->doc); ?></span>
                        </li>
                        <?php endif; ?>
                        <?php if($post->pincode): ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                              <div>
                                <strong><h6 class="my-0">Pincode</h6></strong>

                              </div>
                                  <small class="text-muted"><?php echo e($post->pincode); ?></small>
                        </li>
                        <?php endif; ?>
                        <?php if($post->dob): ?>

                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                  <strong><h6 class="my-0">Date of Birth</h6></strong>

                                </div>
                                    <small class="text-muted"><?php echo e($post->dob); ?></small>
                          </li>
                          <?php endif; ?>
                        <?php if($post->pname): ?>
                          <li class="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                  <strong><h6 class="my-0">Parent Name</h6></strong>

                                </div>
                                    <small class="text-muted"><?php echo e($post->pname); ?></small>
                          </li>
                          <?php endif; ?>




                      </ul>

        </div>


    </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arjun/website/flood/resources/views/posts/show.blade.php ENDPATH**/ ?>